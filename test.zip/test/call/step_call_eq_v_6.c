// [-c test/call/step_call_eq_v_6.c -v 4 -n 2;<11,true>;<12,0,0,1>;<12,5,10,5>]
uint64_t symb;

uint64_t loadVariable(uint64_t x) {
    return x * 5;
}

uint64_t main(uint64_t argc, uint64_t* argv) {
  symb = input(0, 10, 5);
  if(loadVariable(symb) == 5)
    return symb;
  return symb;
}
