// [-c test/call/step_call_eq_v_5.c -v 5 -n 2;<11,10,10,1>;<12,0,5,5>]
uint64_t symb;

uint64_t loadVariable(uint64_t x) {
    return x - 5;
}

uint64_t main(uint64_t argc, uint64_t* argv) {
  symb = input(0, 10, 5);
  if(loadVariable(symb) == 5)
    return symb;
  return symb;
}
