// [-c test/call/step_call_eq_v_2.c -v 4 -n 2;<11,true>;<12,0,4,2>;<12,6,10,2>]
uint64_t symb;

uint64_t loadVariable() {
  return symb;
}

uint64_t main(uint64_t argc, uint64_t* argv) {
  symb = input(0, 10, 2);
  if(loadVariable() == 5)
    return symb;
  return symb;
}
