// [-c test/call/step_call_eq_v_1.c -v 5 -n 2;<10,5,5,1>;<11,0,0,1>;<11,10,10,1>]
uint64_t loadVariable(uint64_t x) {
  return x;
}

uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 10, 5);
  if(loadVariable(x) == 5)
    return x;
  return x;
}
