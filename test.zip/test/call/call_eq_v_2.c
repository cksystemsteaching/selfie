// [-c test/call/call_eq_v_2.c -v 5 -n 2;<11,5,5,1>;<12,0,4,1>;<12,6,10,1>]
uint64_t symb;

uint64_t loadVariable() {
  return symb;
}

uint64_t main(uint64_t argc, uint64_t* argv) {
  symb = input(0, 10, 1);
  if(loadVariable() == 5)
    return symb;
  return symb;
}
