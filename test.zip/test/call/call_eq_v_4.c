// [-c test/call/call_eq_v_4.c -v 5 -n 2;<11,0,0,1>;<12,1,10,1>]
uint64_t symb;

uint64_t loadVariable(uint64_t x) {
    return x + 5;
}

uint64_t main(uint64_t argc, uint64_t* argv) {
  symb = input(0, 10, 1);
  if(loadVariable(symb) == 5)
    return symb;
  return symb;
}
