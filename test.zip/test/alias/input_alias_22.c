// [-c test/alias/input_alias_22.c -v 4 -n 2;<8,0,4,1>;<9,5,10,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  x = input(0, 10, 1);
  y = x;
  if (y < 5)
    return x;
  return y;
}
