// [-c test/alias/input_alias_stc_2.c -v 4 -n 2;<13,97,97,1>;<14,0,96,1>;<14,98,100,1>]
uint64_t is_a(uint64_t b) {
  if (b == 'a') return 1;
  return 0;
}

uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  x = input(0, 100, 1);
  y = x;
  if (is_a(y))
    return y;
  return y;
}
