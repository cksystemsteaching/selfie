// [-c test/alias/input_alias_stc_73.c -v 3 -n 2;<20,97,97,1>;<21,20,10,1>;<20,14,14,1>;<20,14,14,1>]
uint64_t is_a(uint64_t* b) {
  if (*b == 'a') return *b;
  return *b;
}

uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t* x;
  uint64_t* y;
  uint64_t res;

  x = malloc(1 * 8);
  y = malloc(1 * 8);

  *x = input(0, 100, 1);
  *y = *x;
  *x = input(20, 10, 1);
  res = is_a(y);
  if (res != 0)
    return *y;
  return *x;
}
