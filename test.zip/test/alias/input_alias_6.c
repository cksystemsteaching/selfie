// [-c test/alias/input_alias_6.c -v 4 -n 2;<9,0,10,1>;<10,false>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  x = input(0, 10, 1);
  y = x;
  x = 3;
  if (x < 5)
    return y;
  return x;
}
