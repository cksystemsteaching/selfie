// [-c test/alias/input_alias_stc_4.c -v 4 -n 2;<3,14,14,1>]
uint64_t is_a(uint64_t* b) {
  if (*b == 'a') return 1;
  return 0;
}

uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t* x;
  uint64_t* y;

  x = malloc(1 * 8);
  y = malloc(1 * 8);

  *x = input(0, 100, 1);
  *y = *x;
  if (is_a(x))
    return *y;
  return *y;
}
