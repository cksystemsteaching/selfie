// [-c test/alias/input_alias_8.c -v 4 -n 2;<7,3,3,1>;<10,4,4,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 10, 1);
  if (x < 10) {
    x = 3;
    return x;
  }
  x = 4;
  return x;
}
