// [-c test/alias/bidirectional/alias_sum_4.c -v 4 -n 2;<17,70,74,2>;<18,76,80,2>]
// check propagation: (a|b) -> y -> x
// tests for b.
// require: MAX_ALIAS > 0
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t a;
  uint64_t b;

  x = input(10, 20, 2);
  y = 100 - x;
  a = y + 2;
  b = y - 10;

  if (y < 85)
    return b;
  return b;
}
