// [-c test/alias/bidirectional/alias_sum_1.c -v 4 -n 2;<16,80,84,2>;<17,86,90,2>]
// check propagation: (a|b) -> y -> x
// tests for y.
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t a;
  uint64_t b;

  x = input(10, 20, 2);
  y = 100 - x;
  a = y + 2;
  b = y - 10;

  if (y < 85)
    return y;
  return y;
}
