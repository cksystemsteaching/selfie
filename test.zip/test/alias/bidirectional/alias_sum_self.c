// [-c test/alias/bidirectional/alias_sum_self.c -v 4 -n 2;<16,35,45,5>;<17,50,60,5>]
// check propagation: (a|b) -> y -> x
// tests for y.
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t a;
  uint64_t b;

  x = input(10, 20, 2);
  y = x * 5;
  a = y / 2;
  a = a + 10;

  if (y < 75)
    return a;
  return a;
}
