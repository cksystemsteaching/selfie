// [-c test/mul/rs2/err_step_o_wmul_v_1.c -v 4 -n 2;<8,14,14,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = -100;
  y = input(-5, 15, 5);
  z = x * y;
  return z;
}
