// [-c test/mul/rs1/step_one_mul_v.c -v 4 -n 2;<9,0,10,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(0, 10, 5);
  y = 1;
  z = x * y;
  return z;
}
