// [-c test/mul/rs1/mul_v_2.c -v 4 -n 2;<9,8589934580,8589934600,2>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(4294967290, 4294967300, 1);
  y = 2;
  z = x * y;
  return z;
}
