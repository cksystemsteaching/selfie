// [-c test/mul/rs1/zero_mul_v.c -v 4 -n 2;<9,0,0,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(0, 10, 1);
  y = 0;
  z = x * y;
  return z;
}
