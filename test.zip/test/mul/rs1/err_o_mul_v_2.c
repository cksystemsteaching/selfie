// [-c test/mul/rs1/err_o_mul_v_2.c -v 4 -n 2;<8,14,14,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(0, -5, 1);
  y = -10;
  z = x * y;
  return z;
}
