// [-c test/sub/concrete/wsub.c -v 4 -n 2;<3,13,13,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  return 3 - -10;
}
