// [-c test/sub/concrete/sub.c -v 4 -n 2;<3,-86,-86,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  return 3 - 89;
}
