// [-c test/sub/rs2/wsub_v_3.c -v 4 -n 2;<9,-110,-10,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = -100;
  y = input(-90, 10, 1);
  z = x - y;
  return z;
}
