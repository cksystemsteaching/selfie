// [-c test/sub/rs2/step_sub_v_2.c -v 4 -n 2;<9,-1,9,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = 9;
  y = input(0, 10, 5);
  z = x - y;
  return z;
}
