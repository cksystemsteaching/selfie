// [-c test/eq/rs2/eq_v_3.c -v 4 -n 2;<8,1,10,1>;<6,0,0,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 10, 1);
  if(0 == x)
    return x;
  else
    return x;
}
