// [-c test/eq/rs2/step_weq_v_2.c -v 4 -n 2;<6,true>;<7,20,9,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 9, 5);
  if(11 == x)
    return x;
  return x;
}
