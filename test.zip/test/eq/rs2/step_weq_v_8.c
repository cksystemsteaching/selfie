// [-c test/eq/rs2/step_weq_v_8.c -v 4 -n 2;<6,true>;<7,20,-29,33>;<7,4,4,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 4, 33);
  if(2 == x)
    return x;
  return x;
}
