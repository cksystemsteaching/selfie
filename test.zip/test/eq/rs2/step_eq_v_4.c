// [-c test/eq/rs2/step_eq_v_4.c -v 4 -n 2;<8,0,12,3>;<6,true>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 12, 3);
  if(15 == x)
    return x;
  else
    return x;
}
