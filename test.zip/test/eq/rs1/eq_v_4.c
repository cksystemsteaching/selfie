// [-c test/eq/rs1/eq_v_4.c -v 4 -n 2;<8,123,123,1>;<8,124,128,1>;<6,true>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(123, 128, 1);
  if( x * 8 == 991)
    return x;
  else
    return x;
}
