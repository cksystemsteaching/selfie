// [-c test/eq/rs1/weq_v_2.c -v 4 -n 2;<6,true>;<7,20,10,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 10, 1);
  if( x == 11)
    return x;
  return x;
}
