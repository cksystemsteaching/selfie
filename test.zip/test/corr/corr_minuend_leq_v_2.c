// [-c test/corr/corr_minuend_leq_v_2.c -v 5 -n 2;<7,true>;<8,116,128,1>]
uint64_t symb;

uint64_t main(uint64_t argc, uint64_t* argv) {
  symb = input(116, 128, 1);
  if( 31 >= 3 - symb)
    return symb;
  return symb;
}
