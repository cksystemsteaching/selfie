// [-c test/corr/corr_div_v_1.c -v 5 -n 2;<11,124,127,1>;<12,116,123,1>;<12,128,128,1>]
uint64_t symb;

uint64_t loadVariable(uint64_t x) {
    return x / 4;
}

uint64_t main(uint64_t argc, uint64_t* argv) {
  symb = input(116, 128, 1);
  if(loadVariable(symb) == 31)
    return symb;
  return symb;
}
