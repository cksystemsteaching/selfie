// [-c test/corr/err_corr_minuend_eq_v_1.c -v 5 -n 2;<6,14,14,1>]
uint64_t symb;

uint64_t main(uint64_t argc, uint64_t* argv) {
  symb = input(116, 128, 1);
  if(3 - symb == 31)
    return symb;
  return symb;
}
