// [-c test/corr/lt/mul/rs1/step_mul_v_5.c -v 4 -n 2;<10,true>;<12,0,130,65>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(0, 10, 5);
  y = 3;
  z = x * 13;
  if(y * z < y * 0 * 13)
    return z;
  else
    return z;
}
