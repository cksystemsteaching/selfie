// [-c test/corr/lt/mul/rs1/mul_shift_stc3.c -v 4 -n 2;<8,8,16,2>;<10,18,28,2>]
uint64_t main() {
  uint64_t a;
  uint64_t b;
  a = input(4, 14, 1);                    // [4,14]
  b = a * 2;                              // [8, 28]
  if (b + 5 < 22) {                       // [13, 33]
    return b;                             // [13, 21] -> [8,16] -> [4, 8]
  }
  return b;                               // [23, 32] -> [18, 28] -> [9, 14]
}
