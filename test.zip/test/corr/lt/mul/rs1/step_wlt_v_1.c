// [-c test/corr/lt/mul/rs1/step_wlt_v_1.c -v 4 -n 2;<6,0,5,5>;<7,-5,-5,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(-5, 5, 5);
  if(x * 27 < 15 * 27)
    return x;
  return x;
}
