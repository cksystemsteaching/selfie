// [-c test/corr/lt/mul/rs2/err_wlt_v_1.c -v 4 -n 2;<5,14,14,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 10, 1);
  if(5 * 4 * 8 * 87 < x * 4 * 8 * 87)
    return x;
  return x;
}
