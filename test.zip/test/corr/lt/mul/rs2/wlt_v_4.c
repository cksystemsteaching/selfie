// [-c test/corr/lt/mul/rs2/wlt_v_4.c -v 4 -n 2;<7,0,2,1>;<6,-2,-1,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(-2, 2, 1);
  if(25 * 78 < x * 78)
    return x;
  return x;
}
