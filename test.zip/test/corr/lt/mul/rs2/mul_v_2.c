// [-c test/corr/lt/mul/rs2/mul_v_2.c -v 4 -n 2;<8,0,10,1>;<6,true>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 10, 1);
  if(15 * 205 < x * 79)
    return x;
  else
    return x;
}
