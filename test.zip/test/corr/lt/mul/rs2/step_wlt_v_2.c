// [-c test/corr/lt/mul/rs2/step_wlt_v_2.c -v 4 -n 2;<6,15,20,5>;<7,0,10,5>;<6,-20,-5,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(-20, 20, 5);
  if(10 * 38 * 10 < x * 38 * 10)
    return x;
  return x;
}
