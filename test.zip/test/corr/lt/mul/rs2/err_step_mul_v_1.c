// [-c test/corr/lt/mul/rs2/err_step_mul_v_1.c -v 4 -n 2;<7,14,14,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  x = input(10, 15, 5);
  y = -3;
  if(y * 15 < y * x)
    return x;
  else
    return x;
}
