// [-c test/corr/lt/mul/rs2/mul_v_1.c -v 4 -n 2;<7,0,5,1>;<6,6,10,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 10, 1);
  if(5 * 89 < x * 89)
    return x;
  return x;
}
