// [-c test/corr/lt/mul/rs2/step_mul_v_4.c -v 4 -n 2;<12,0,0,1>;<10,15,30,15>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(0, 10, 5);
  y = 3;
  z = y * x;
  if(y * 13 < z * 13)
    return z;
  else
    return z;
}
