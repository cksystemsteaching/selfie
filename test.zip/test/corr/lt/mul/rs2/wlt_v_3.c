// [-c test/corr/lt/mul/rs2/wlt_v_3.c -v 4 -n 2;<6,-20,-1,1>;<6,11,20,1>;<7,0,10,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(-20, 20, 1);
  if(10 * 487 < x * 487)
    return x;
  return x;
}
