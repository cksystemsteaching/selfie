// [-c test/corr/lt/mul/rs2/step_wlt_v_1.c -v 4 -n 2;<6,-5,-5,1>;<7,0,5,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(-5, 5, 5);
  if(15 * 27 < x * 27)
    return x;
  return x;
}
