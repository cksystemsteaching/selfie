// [-c test/corr/lt/mul/rs2/err_step_wlt_v_3.c -v 4 -n 2;<5,14,14,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 9, 5);
  if(25 * 77 * -8 < x * 77 * -8)
    return x;
  return x;
}
