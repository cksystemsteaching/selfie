// [-c test/corr/lt/mul/rs2/step_mul_v_1.c -v 4 -n 2;<9,0,5,5>;<8,10,10,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  x = input(0, 10, 5);
  y = 89;
  if(5 * y < x * y)
    return x;
  return x;
}
