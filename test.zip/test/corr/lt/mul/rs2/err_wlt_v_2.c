// [-c test/corr/lt/mul/rs2/err_wlt_v_2.c -v 4 -n 2;<5,14,14,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 10, 1);
  if(25 * 78 < x * 78)
    return x;
  return x;
}
