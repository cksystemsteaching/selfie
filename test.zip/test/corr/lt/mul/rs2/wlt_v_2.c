// [-c test/corr/lt/mul/rs2/wlt_v_2.c -v 4 -n 2;<6,-10,-1,1>;<7,0,10,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(-10, 10, 1);
  if(11 * 1 * 2 * 3 * 4 * 5 * 6 < x * 1 * 2 * 3 * 4 * 5 * 6)
    return x;
  return x;
}
