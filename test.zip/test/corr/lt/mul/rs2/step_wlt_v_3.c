// [-c test/corr/lt/mul/rs2/step_wlt_v_3.c -v 4 -n 2;<7,0,10,5>;<6,-10,-5,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(-10, 10, 5);
  if(25 * 78 < x * 78)
    return x;
  return x;
}
