// [-c test/corr/lt/mix/rs1/step_addsub_v_1.c -v 4 -n 2;<6,0,0,1>;<7,5,50,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 50, 5);
  if(x + 89 - 10 < 5 + 89 - 10)
    return x;
  return x;
}
