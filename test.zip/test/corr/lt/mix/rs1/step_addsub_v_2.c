// [-c test/corr/lt/mix/rs1/step_addsub_v_2.c -v 4 -n 2;<6,0,16,8>;<7,24,664,8>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 664, 8);
  if(5 - 10 + x + 89 < 10 + 5 + 89)
    return x;
  return x;
}
