// [-c test/corr/lt/mix/rs1/addsub_v_4.c -v 4 -n 2;<7,0,10,1>;<6,true>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 10, 1);
  if(x - 89 - 40 + 50 < 10 - 5 + 89)
    return x;
  return x;
}
