// [-c test/corr/lt/sub/rs1/step_wlt_v_2.c -v 4 -n 2;<6,-11,9,5>;<7,20,-16,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 9, 5);
  if(x - -12 < 11 - -12)
    return x;
  return x;
}
