// [-c test/corr/lt/sub/rs1/step_wlt_v_4.c -v 4 -n 2;<6,385,4,5>;<7,9,9,1>;<7,20,380,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 9, 5);
  if(x - -8 - 389 - 1 < 5 - -8 - 389 - 1)
    return x;
  return x;
}
