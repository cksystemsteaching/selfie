// [-c test/corr/lt/sub/rs1/step_wlt_v_8.c -v 4 -n 2;<7,4,4,1>;<7,20,-12008,33>;<6,-11975,-29,33>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 4, 33);
  if(x - 6 - -12000 < 2 - 6 - -12000)
    return x;
  return x;
}
