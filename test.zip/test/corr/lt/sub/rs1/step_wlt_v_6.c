// [-c test/corr/lt/sub/rs1/step_wlt_v_6.c -v 4 -n 2;<7,4,4,1>;<6,14111,-29,33>;<7,20,14078,33>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 4, 33);
  if(x - 14087 < -10 - 14087)
    return x;
  return x;
}
