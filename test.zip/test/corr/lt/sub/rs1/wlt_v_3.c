// [-c test/corr/lt/sub/rs1/wlt_v_3.c -v 4 -n 2;<6,487,9,1>;<7,10,10,1>;<7,20,486,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 10, 1);
  if(x - 487 < 10 - 487)
    return x;
  return x;
}
