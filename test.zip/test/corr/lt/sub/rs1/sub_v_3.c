// [-c test/corr/lt/sub/rs1/sub_v_3.c -v 4 -n 2;<8,10,15,1>;<6,true>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(10, 15, 1);
  if(x - 3 - 5 - -167 < 0)
    return x;
  else
    return x;
}
