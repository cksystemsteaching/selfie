// [-c test/corr/lt/sub/rs1/wlt_v_4.c -v 4 -n 2;<6,99,4,1>;<7,5,10,1>;<7,20,98,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 10, 1);
  if(x - 4 - 8 - 87 < 5 - 4 - 8 - 87)
    return x;
  return x;
}
