// [-c test/corr/lt/sub/rs1/step_sub_v_2.c -v 4 -n 2;<8,10,10,1>;<9,0,5,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  x = input(0, 10, 5);
  y = -9;
  if(y - 7 - x < y - 7 - 5)
    return x;
  return x;
}
