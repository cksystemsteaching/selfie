// [-c test/corr/lt/sub/rs2/sub_v_3.c -v 4 -n 2;<6,10,15,1>;<8,false>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(10, 15, 1);
  if(0 < x - 3 - 5 - -167)
    return x;
  else
    return x;
}
