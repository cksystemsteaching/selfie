// [-c test/corr/lt/sub/rs2/step_wlt_v_7.c -v 4 -n 2;<7,20,340877,33>;<6,340910,-62,33>;<7,-29,4,33>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 4, 33);
  if(x - 1 - 340897 < -29 - 1 - 340897)
    return x;
  return x;
}
