// [-c test/corr/lt/sub/rs2/step_wlt_v_3.c -v 4 -n 2;<7,50,9,5>;<6,20,45,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 9, 5);
  if(10 - 38 - 10 < x - 38 - 10)
    return x;
  return x;
}
