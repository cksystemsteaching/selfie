// [-c test/corr/lt/sub/rs2/step_wlt_v_4.c -v 4 -n 2;<7,385,4,5>;<6,9,9,1>;<6,20,380,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 9, 5);
  if(5 - -8 - 389 - 1 < x - -8 - 389 - 1)
    return x;
  return x;
}
