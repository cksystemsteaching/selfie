// [-c test/corr/lt/sub/rs2/wlt_v_1.c -v 4 -n 2;<7,3527,10,1>;<6,20,3526,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 10, 1);
  if(15 - 38 - 3489 < x - 38 - 3489)
    return x;
  return x;
}
