// [-c test/gt/rs1/step_gt_v_3.c -v 4 -n 2;<8,0,10,5>;<6,true>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 10, 5);
  if(x > 15)
    return x;
  else
    return x;
}
