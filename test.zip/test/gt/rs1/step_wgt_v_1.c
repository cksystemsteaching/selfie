// [-c test/gt/rs1/step_wgt_v_1.c -v 4 -n 2;<7,4,9,5>;<6,20,-1,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 9, 5);
  if(x > 15)
    return x;
  return x;
}
