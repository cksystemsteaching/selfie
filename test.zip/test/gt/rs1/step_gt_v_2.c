// [-c test/gt/rs1/step_gt_v_2.c -v 4 -n 2;<6,6,9,3>;<7,0,3,3>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 9, 3);
  if(x > 5)
    return x;
  return x;
}
