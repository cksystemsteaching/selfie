// [-c test/gt/rs1/step_wgt_v_6.c -v 4 -n 2;<6,true>;<7,4,4,1>;<7,20,-29,33>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 4, 33);
  if(x > -10)
    return x;
  return x;
}
