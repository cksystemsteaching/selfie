// [-c test/gt/rs2/wgt_v_1.c -v 4 -n 2;<7,20,-1,1>;<6,0,10,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 10, 1);
  if(15 > x)
    return x;
  return x;
}
