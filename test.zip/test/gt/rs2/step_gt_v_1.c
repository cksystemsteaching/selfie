// [-c test/gt/rs2/step_gt_v_1.c -v 4 -n 2;<7,5,10,5>;<6,0,0,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 10, 5);
  if(5 > x)
    return x;
  return x;
}
