// [-c test/gt/rs2/step_gt_v_2.c -v 4 -n 2;<7,6,9,3>;<6,0,3,3>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 9, 3);
  if(5 > x)
    return x;
  return x;
}
