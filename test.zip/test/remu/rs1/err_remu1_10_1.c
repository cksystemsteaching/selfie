// [-c test/remu/rs1/err_remu1_10_1.c -v 4 -n 2;<8,14,14,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(-5, 15, 1);
  y = -100;
  z = x % y;
  return z;
}
