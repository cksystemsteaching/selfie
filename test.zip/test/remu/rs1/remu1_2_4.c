// [-c test/remu/rs1/remu1_2_4.c -v 4 -n 2;<9,0,80,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(-2,80,1);
  y = -2;
  z = x % y;
  return z;
}
