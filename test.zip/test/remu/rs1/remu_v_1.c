// [-c test/remu/rs1/remu_v_1.c -v 4 -n 2;<9,0,-2,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(0, -1, 1);
  y = -1;
  z = x % y;
  return z;
}
