// [-c test/remu/rs1/err_remu2_4.c -v 4 -n 2;<9,3,15,4>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(-1,15,4);
  y = 16;
  z = x % y;
  return z;
}
