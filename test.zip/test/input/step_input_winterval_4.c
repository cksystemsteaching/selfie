// [-c test/input/step_input_winterval_4.c -v 4 -n 2;<6,20,10,7>]

uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 10, 7);
  return x;
}
