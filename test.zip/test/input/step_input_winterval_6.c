// [-c test/input/step_input_winterval_6.c -v 4 -n 2;<6,19,11,10>]

uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(19, 11, 10);
  return x;
}
