// [-c test/input/step_input_winterval_5.c -v 4 -n 2;<6,-5,15,5>]

uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(-5, 15, 5);
  return x;
}
