// [-c test/input/step_input_winterval_2.c -v 4 -n 2;<6,-111,42,13>]

uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(-111, 42, 13);
  return x;
}
