// [-c test/leq/rs2/step_leq_v_1.c -v 4 -n 2;<7,0,0,1>;<6,5,10,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 10, 5);
  if(5 <= x)
    return x;
  return x;
}
