// [-c test/leq/rs2/wleq_v_4.c -v 4 -n 2;<7,0,4,1>;<6,5,10,1>;<6,20,-1,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 10, 1);
  if (5 <= x)
    return x;
  return x;
}
