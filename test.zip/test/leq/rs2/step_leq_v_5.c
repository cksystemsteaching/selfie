// [-c test/leq/rs2/step_leq_v_5.c -v 4 -n 2;<6,0,10,5>;<8,false>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 10, 5);
  if(0 <= x)
    return x;
  else
    return x;
}
