// [-c test/leq/rs1/step_wleq_v_4.c -v 4 -n 2;<6,4,4,1>;<7,9,9,1>;<7,20,-1,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 9, 5);
  if( x <= 5)
    return x;
  return x;
}
