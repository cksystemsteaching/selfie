// [-c test/leq/rs1/step_wleq_v_6.c -v 4 -n 2;<6,4,4,1>;<6,20,-29,33>;<7,false>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 4, 33);
  if( x <= -10)
    return x;
  return x;
}
