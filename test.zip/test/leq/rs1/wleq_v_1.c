// [-c test/leq/rs1/wleq_v_1.c -v 4 -n 2;<6,0,10,1>;<7,20,-1,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(20, 10, 1);
  if( x <= 15)
    return x;
  return x;
}
