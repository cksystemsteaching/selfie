// [-c test/divu/rs1/err_divu2_2.c -v 4 -n 2;<8,14,14,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(-5, 15, 3);
  y = 3;
  z = x / y;
  return z;
}
