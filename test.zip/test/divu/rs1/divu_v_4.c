// [-c test/divu/rs1/divu_v_4.c -v 4 -n 2;<9,0,2,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(0, 178, 1);
  y = 89;
  z = x / y;
  return z;
}
