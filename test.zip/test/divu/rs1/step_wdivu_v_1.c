// [-c test/divu/rs1/step_wdivu_v_1.c -v 4 -n 2;<9,0,1844674407370955160,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(19,11,10);
  y = 10;
  z = x / y;
  return z;
}
