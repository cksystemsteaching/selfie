// [-c test/add/rs1/top_add_v.c -v 5 -n 2;<9,1,0,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = input(0, -1, 1);
  y = 1;
  z = x + y;
  return z;
}
