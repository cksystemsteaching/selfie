// [-c test/add/rs2/top_wadd_v.c -v 5 -n 2;<9,-4,-5,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = 1;
  y = input(-5, -6, 1);
  z = x + y;
  return z;
}
