// [-c test/add/rs2/add_self_v_1.c -v 2 -n 2;<6,1,11,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  x = input(0, 10, 1);
  x = 1 + x;
  return x;
}
