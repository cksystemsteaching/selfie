// [-c test/add/rs2/step_wadd_v_3.c -v 5 -n 2;<9,-105,-5,5>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  uint64_t x;
  uint64_t y;
  uint64_t z;
  x = -15;
  y = input(-90, 10, 5);
  z = x + y;
  return z;
}
