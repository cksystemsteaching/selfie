// [-c test/add/concrete/add.c -v 5 -n 2;<3,92,92,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  return 3 + 89;
}
