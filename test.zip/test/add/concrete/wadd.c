// [-c test/add/concrete/wadd.c -v 5 -n 2;<3,-7,-7,1>]
uint64_t main(uint64_t argc, uint64_t* argv) {
  return 3 + -10;
}
